from datetime import date
from PIL import Image
import json
import random
import requests
import os

def saveGet5(setName):
    """
    calls get_each_over_5_dollars and saves it to a file
    -----------------
    just takes in a set name
    """
    
    #+ '_RID' + str(random.randint(0,999))

    json_data = get5OrMoreDollars(setName)
    if json_data:
        json_data_string = json.dumps(json_data, indent=4)
        unqiueName = setName + '-' + formatted_date + '.txt'
        with open(unqiueName, 'w') as td:
            td.write(json_data_string)
        print("Saved file successfully under " + os.getcwd() + " as " + unqiueName)
#End saveGet5

def saveCard(searchName):
    """
    Saves a txt of a individual card
    -------
    takes a name.
    """

    txt_data = getCard(searchName)
    if txt_data:
        unqiueName = searchName + '-' + formatted_date + '.txt'
        with open(unqiueName, "w") as td:
            td.write(txt_data['txt_data'])
        print("Saved file successfully under " + os.getcwd() + " as " + unqiueName)
#End saveCard

def saveCardImage(searchName, setName):
    """
    Saves a image of a individual card
    -------
    takes a name.
    """

    img_data = getCardImage(searchName, setName)
    if img_data:
        unqiueName = searchName + '-' + formatted_date + '.jpg'
        with open(unqiueName, "wb") as id:
            id.write(img_data)
        print("Saved file successfully under " + os.getcwd() + " as " + unqiueName)
#End saveCard

def get5OrMoreDollars(setName):
    """ Gets every card from the set provided over 3.49$ american, or 5$ canadian
        ------------------
        takes in the set name, returns a text file list of each card
    """

    newSearch = '(game:paper) set:' + setName + ' is:booster usd>3.49'
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/search"
    
    headers = {
        'User-Agent': 'scryscrape/0.3',
        'Accept': '*/*'
    }

    params = {
        'q' : newSearch,
        'order' : 'usd',
        'dir' : 'desc',
        'unique' : 'prints',
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params, headers=headers, allow_redirects=True)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error {response.status_code}: {response.text}")
            return None
    
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#End get_each_over-5_dollars()

def getCard(cardName):
    """
    Get a magic card from Scryfall API as text to terminal.
    """
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/named"
    headers = {
        'User-Agent': 'scryscraper/0.3',
        'Accept': '*/*'
    }
    params = {
        'fuzzy': cardName
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params,headers=headers,allow_redirects=True)
        if response.status_code == 200:
            return response.raw
        else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#End get_card()

def getCardImage(cardName, setName):
    """
    Get a magic card image from Scryfall API as text to terminal.
    -------
    Takes a name and a set code
    """
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/named"
    headers = {
        'User-Agent': 'scryscraper/0.3',
        'Accept': '*/*'
    }
    params = {
        'fuzzy': cardName,
        'format' : 'image',
        'version': 'large',
        'set' : setName
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params,headers=headers,allow_redirects=True)
        if response.status_code == 200:
            return response.content
        else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#End getCardImage()

def getFromText(fileName, setName):
    """
    Takes the top 5 most expensive cards from play boosters in the set and returns images for each
    ---------
    takes a file name of a file in the same directory
    """
    
    info = []

    with open(fileName, "r", encoding="utf-8") as f:
        data = json.load(f)

    for card in data.get("data", [])[:5]:
        name = card.get("name")
        #number = card.get("collector_number")
        if name is not None: #and number is not None:
            info.append(f"{name}")
    for name in info:
        saveCardImage(name,setName)
#End getFromText()


if __name__ == "__main__":
    
    # 1, response is a request equal to the base url + endpoint + params + headers + user + accepts.
    # 2, response returns a JSON, or whatever type the method specifies.
    # 3, we create a new object that is equal to the method that returns a JSON, therefore the initial object is a JSON object.
    # 4, if the object is real, we write the information in the object to the terminal.

    today = date.today()
    formatted_date = today.strftime("%Y-%m-%d")

    searchName = 'famished worldsire'  # THIS IS WHERE YOU SEARCH FOR NAME ------------------------------------------------------------------------&&&&&
    setName = 'unf' # THIS IS WHERE YOU SEARCH FOR SET      ------------------------------------------------------------------------&&&&&
     
    #getFromText('unf-2025-12-05.txt', 'unf')
    #saveGet5(setName) #save the set first, then use getFromText
    #saveCard(searchName) 
    #saveCardImage(searchName)