from datetime import date
import json
from PIL import Image
import random
import requests
import os

def saveGet5(setName):
    """
    calls get_each_over_5_dollars and saves it to a file
    -----------------
    just takes in a set name
    """
    
    json_data = get_each_over_5_dollars(setName)
    if json_data:
        json_data_string = json.dumps(json_data, indent=4)
        unqiueName = setName + '-' + formatted_date + '_RID' + str(random.randint(0,999)) + '.txt'
        with open(unqiueName, 'w') as td:
            td.write(json_data_string)
        print("Saved file successfully under " + os.getcwd() + " as " + unqiueName)
#End saveGet5

def saveCard(searchName):
    txt_data = get_card(searchName)
    if txt_data:
        unqiueName = searchName + '-' + formatted_date + '_RID' + str(random.randint(0,999)) + '.txt'
        with open(unqiueName, "w") as td:
            td.write(txt_data['txt_data'])
        print("Saved file successfully under " + os.getcwd() + " as " + unqiueName)
#End saveCard

def get_each_over_5_dollars(set_name):
    """ Gets every card from the set provided over 3.49$ american, or 5$ canadian
        ------------------
        takes in the set name, returns a text file list of each card
    """

    newSearch = '(game:paper) set:' + set_name + ' usd>3.49'
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/search"
    
    headers = {
        'User-Agent': 'scryscrape/0.2',
        'Accept': '*/*'
    }

    params = {
        'q' : newSearch,
        'order' : 'usd',
        'dir' : 'desc',
        'unique' : 'prints'
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params, headers=headers, allow_redirects=True)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error {response.status_code}: {response.text}")
            return None
    
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#End get_each_over-5_dollars()

def get_card(card_name):
    """
    Get a magic card from Scryfall API as text to terminal.
    """
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/named"
    headers = {
        'User-Agent': 'scryscrape/0.1',
        'Accept': '*/*'
    }
    params = {
        'fuzzy': card_name
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params,headers=headers,allow_redirects=True)
        if response.status_code == 200:
            return response.raw
        else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#End get_card()

if __name__ == "__main__":
    
    # 1, response is a request equal to the base url + endpoint + params + headers + user + accepts.
    # 2, response returns a JSON, or whatever type the method specifies.
    # 3, we create a new object that is equal to the method that returns a JSON, therefore the initial object is a JSON object.
    # 4, if the object is real, we write the information in the object to the terminal.

    today = date.today()
    formatted_date = today.strftime("%Y-%m-%d")

    searchName = 'famished worldsire'  # THIS IS WHERE YOU SEARCH FOR NAME ------------------------------------------------------------------------&&&&&
    setName = 'dom' # THIS IS WHERE YOU SEARCH FOR SET      ------------------------------------------------------------------------&&&&&
     
    saveGet5(setName)
    #saveCard(searchName)