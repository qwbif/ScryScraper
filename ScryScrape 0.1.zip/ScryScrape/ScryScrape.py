import requests

def get_top_five(set_name, image_version="large"):
    """ Gets the top five most expensive card from the set provided
        ------------------
        takes in the set name, sets can only return JSON info, and this has the optional params of image size.
    """

    base_url = "https://api.scryfall.com"
    endpoint = "/sets"
    
    headers = {
        'User-Agent': 'scryscrape/0.1',
        'Accept': '*/*'
    }

    params = {
        'fuzzy': set_name,
        'version': image_version,
        'format': "json"
    }

    try:
        response = requests.get(f"{base_url}{endpoint}",params=params, headers=headers, allow_redirects=True)

        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error {response.status_code}: {response.text}")
            return None
    
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#//////////////////////// END OF SECONDARY FUNCTION

def get_card(card_name, format_type="json", image_version="large", face="front"):
    """
    Get a Magic card from Scryfall API with support for multiple formats.
    ------
    Takes in optional params for return type, image size, and front/back face

    """
    base_url = "https://api.scryfall.com"
    endpoint = "/cards/named"
    
    headers = {
        'User-Agent': 'scryscrape/0.1',
        'Accept': '*/*'
    }
    
    params = {
        'fuzzy': card_name,
        'format': format_type
    }
    
    if format_type == "image":
        params['version'] = image_version
        if face == "back":
            params['face'] = face
    
    try:
        response = requests.get(f"{base_url}{endpoint}", params=params, headers=headers, allow_redirects=True)
        
        if format_type == "json":
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error {response.status_code}: {response.text}")
                return None
       #---------------------------------------------------------------------- ^ json         
        elif format_type == "csv":
            if response.status_code == 200:
                return {
                    'data': response.text,
                    'headers': {
                        'has_more': response.headers.get('X-Scryfall-Has-More'),
                        'next_page': response.headers.get('X-Scryfall-Next-Page')
                    }
                }
            else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        #---------------------------------------------------------------------- ^ csv
        elif format_type == "text":
            if response.status_code == 200:
                return {
                    'data': response.text,
                    'headers': {
                        'card_permalink': response.headers.get('X-Scryfall-Card'),
                        'card_image': response.headers.get('X-Scryfall-Card-Image')
                    }
                }
            else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        #---------------------------------------------------------------------- ^ text        
        elif format_type == "image":
            if response.status_code == 200:
                return {
                    'image_data': response.content,
                    'content_type': response.headers.get('Content-Type'),
                    'card_permalink': response.headers.get('X-Scryfall-Card'),
                    'card_image': response.headers.get('X-Scryfall-Card-Image')
                }
            else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        #---------------------------------------------------------------------- ^ image        
        elif format_type == "file":
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error {response.status_code}: {response.text}")
                return None
        #---------------------------------------------------------------------- ^ file        
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
#//////////////////////// END OF MAIN FUNCTION

if __name__ == "__main__":
    """
    image_data = get_card("card", format_type="image", image_version="large")
    if image_data:
        with open("card.jpg", "wb") as f:
            f.write(image_data['image_data'])
        print("Saved image successfully under C:)Users)squid)Documents)VsCodeProjects)ScryScrape")
    """
    image_data2 = get_top_five("m20")
    if image_data2:
        with open("card.jpg", "wb") as f:
            f.write(image_data2['image_data2'])
        print("saved image successfully")
            

    """
    card_data = get_card("") # insert name
    if card_data:
        print(f"Card: {card_data.get('name')}")
        print(f"Mana Cost: {card_data.get('mana_cost')}")
        print(f"Type: {card_data.get('type_line')}")
        print(f"Oracle Text: {card_data.get('oracle_text')}")
    """
    